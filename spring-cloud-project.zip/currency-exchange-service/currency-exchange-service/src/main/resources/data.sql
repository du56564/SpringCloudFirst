insert into exchange_value(id,currency_from,currency_to,conversion_multiple,port) 
values(10002,'EURO','INR',85,0);
insert into exchange_value(id,currency_from,currency_to,conversion_multiple,port) 
values(10003,'AUD','INR',25,0);